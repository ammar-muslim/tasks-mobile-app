import { DatabaseSync } from 'node:sqlite';

class Db {
  constructor() { this.d = new DatabaseSync(':memory:'); }
  async execAsync(sql) { this.d.exec(sql); }
  async runAsync(sql, params = []) {
    const r = this.d.prepare(sql).run(...params);
    return { changes: Number(r.changes), lastInsertRowId: Number(r.lastInsertRowid) };
  }
  async getFirstAsync(sql, params = []) { return this.d.prepare(sql).get(...params) ?? null; }
  async getAllAsync(sql, params = []) { return this.d.prepare(sql).all(...params); }
  async withTransactionAsync(fn) {
    this.d.exec('BEGIN');
    try { await fn(); this.d.exec('COMMIT'); } catch (e) { this.d.exec('ROLLBACK'); throw e; }
  }
}

let db;
export async function openDatabaseAsync() { return (db ??= new Db()); }
export function __reset() { db = undefined; }
