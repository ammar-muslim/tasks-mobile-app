// Lets the real src/db code run under plain Node for tests:
//  - 'expo-sqlite' is replaced by a thin shim over node:sqlite (same API subset we use)
//  - extensionless relative imports ('./client') resolve to .ts
import { register } from 'node:module';
register('./hooks.mjs', import.meta.url);
