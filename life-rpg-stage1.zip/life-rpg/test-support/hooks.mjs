import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const shim = new URL('./expo-sqlite-shim.mjs', import.meta.url).href;

export async function resolve(specifier, context, next) {
  if (specifier === 'expo-sqlite') return { url: shim, shortCircuit: true };
  if (specifier.startsWith('.') && !/\.[a-z]+$/.test(specifier) && context.parentURL) {
    const url = new URL(specifier + '.ts', context.parentURL);
    if (existsSync(fileURLToPath(url))) return next(url.href, context);
  }
  return next(specifier, context);
}
