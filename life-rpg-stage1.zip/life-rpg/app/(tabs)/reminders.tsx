import { NotBuilt } from '../../src/features/NotBuilt';
import { t } from '../../src/i18n';

export default function Screen() {
  return <NotBuilt title={t('reminders')} stage={4} />;
}
