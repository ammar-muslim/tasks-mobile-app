import React from 'react';
import { Tabs } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useTheme } from '../../src/theme';
import { t } from '../../src/i18n';

export default function TabsLayout() {
  const { colors } = useTheme();
  const icon = (name: React.ComponentProps<typeof Feather>['name']) => ({ color, size }: { color: string; size: number }) => <Feather name={name} size={size} color={color} />;
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.primary, tabBarInactiveTintColor: colors.textMuted, tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border } }}>
      <Tabs.Screen name="index" options={{ title: t('today'), tabBarIcon: icon('sun') }} />
      <Tabs.Screen name="tasks" options={{ title: t('tasks'), tabBarIcon: icon('check-square') }} />
      <Tabs.Screen name="habits" options={{ title: t('habits'), tabBarIcon: icon('repeat') }} />
      <Tabs.Screen name="reminders" options={{ title: t('reminders'), tabBarIcon: icon('bell') }} />
      <Tabs.Screen name="hero" options={{ title: t('hero'), tabBarIcon: icon('shield') }} />
    </Tabs>
  );
}
