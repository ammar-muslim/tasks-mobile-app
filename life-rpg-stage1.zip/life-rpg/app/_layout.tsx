import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { getDb } from '../src/db/client';
import { setLanguage } from '../src/i18n';
import { Txt } from '../src/ui/components';

setLanguage('ar'); // Arabic RTL by default; English strings are ready (see src/i18n)

export default function RootLayout() {
  const [ready, setReady] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    getDb().then(() => setReady(true)).catch((e) => setErr(String(e?.message ?? e)));
  }, []);

  if (err) return <View style={{ flex: 1, justifyContent: 'center', padding: 24 }}><Txt>{err}</Txt></View>;
  if (!ready) return <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator /></View>;

  return (
    <>
      <StatusBar style="auto" />
      <Stack screenOptions={{ headerShown: false }} />
    </>
  );
}
