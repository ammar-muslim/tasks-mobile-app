import React, { useState } from 'react';
import { KeyboardAvoidingView, Modal, Platform, Pressable, TextInput, View } from 'react-native';
import { Txt } from '../../ui/components';
import { radius, spacing, useTheme } from '../../theme';
import { t } from '../../i18n';
import { createTask } from '../../db/taskService';
import { bump } from '../../state/dataVersion';
import type { ISODate, Priority } from '../../domain/types.ts';

/** Quick-add: title only is enough; priority is one tap. Richer fields arrive with the full task form (Stage 2). */
export function AddTaskSheet({ visible, date, onClose }: { visible: boolean; date: ISODate; onClose: () => void }) {
  const { colors } = useTheme();
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>(0);

  async function save() {
    if (!title.trim()) return;
    await createTask({ title, dueDate: date, priority });
    setTitle('');
    setPriority(0);
    bump();
    onClose();
  }

  const labels = [t('none'), t('low'), t('medium'), t('high')];

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: '#0006' }} onPress={onClose} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={{ backgroundColor: colors.surface, padding: spacing.lg, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, gap: spacing.md }}>
          <TextInput
            autoFocus
            value={title}
            onChangeText={setTitle}
            onSubmitEditing={save}
            placeholder={t('taskTitle')}
            placeholderTextColor={colors.textMuted}
            returnKeyType="done"
            style={{ color: colors.text, fontSize: 18, paddingVertical: spacing.sm, textAlign: 'auto' }}
          />
          <View style={{ flexDirection: 'row', gap: spacing.sm }}>
            {labels.map((l, i) => (
              <Pressable key={i} onPress={() => setPriority(i as Priority)}
                style={{ paddingHorizontal: spacing.md, paddingVertical: 6, borderRadius: radius.pill, backgroundColor: priority === i ? colors.prio[i] : colors.surfaceAlt }}>
                <Txt size={13} color={priority === i ? '#fff' : colors.textMuted}>{l}</Txt>
              </Pressable>
            ))}
          </View>
          <Pressable onPress={save} style={{ backgroundColor: colors.primary, padding: spacing.md, borderRadius: radius.md, alignItems: 'center', opacity: title.trim() ? 1 : 0.5 }}>
            <Txt bold color={colors.primaryText}>{t('save')}</Txt>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}
