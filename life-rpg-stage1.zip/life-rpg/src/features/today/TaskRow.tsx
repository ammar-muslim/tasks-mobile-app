import React from 'react';
import { Pressable, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Checkbox, Txt } from '../../ui/components';
import { computeTaskReward } from '../../domain/rewards.ts';
import { radius, spacing, useTheme } from '../../theme';
import type { Task } from '../../db/taskService';

export function TaskRow({ task, onToggle, onPress }: { task: Task; onToggle: (t: Task) => void; onPress?: (t: Task) => void }) {
  const { colors } = useTheme();
  const done = task.status === 'done';
  const prioColor = colors.prio[task.priority];
  const xp = computeTaskReward({ priority: task.priority, difficulty: task.difficulty, estimatedMinutes: task.estimatedMinutes }).xp;

  return (
    <Pressable onPress={() => onPress?.(task)} style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.md, paddingHorizontal: spacing.lg, opacity: done ? 0.55 : 1 }}>
      <Checkbox checked={done} onPress={() => onToggle(task)} color={task.priority ? prioColor : undefined} />
      <View style={{ flex: 1 }}>
        <Txt bold style={done ? { textDecorationLine: 'line-through' } : undefined}>{task.title}</Txt>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: 2 }}>
          {task.scheduledTime ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
              <Feather name="clock" size={12} color={colors.textMuted} />
              <Txt muted size={12}>{task.scheduledTime}</Txt>
            </View>
          ) : null}
          {task.recurrence ? <Feather name="repeat" size={12} color={colors.textMuted} /> : null}
          {task.tags.slice(0, 2).map((tg) => (
            <View key={tg} style={{ backgroundColor: colors.surfaceAlt, borderRadius: radius.pill, paddingHorizontal: 8, paddingVertical: 1 }}>
              <Txt muted size={11}>#{tg}</Txt>
            </View>
          ))}
        </View>
      </View>
      <Txt size={12} color={colors.gold} bold>+{xp} XP</Txt>
    </Pressable>
  );
}
