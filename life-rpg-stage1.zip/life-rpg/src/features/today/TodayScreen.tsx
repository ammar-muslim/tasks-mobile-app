import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Card, EmptyState, Fab, ProgressBar, Txt } from '../../ui/components';
import { TaskRow } from './TaskRow';
import { AddTaskSheet } from './AddTaskSheet';
import { radius, spacing, useTheme } from '../../theme';
import { t, locale } from '../../i18n';
import { addDays, startOfWeek, todayISO } from '../../domain/dates.ts';
import { completionPercent } from '../../domain/habits.ts';
import { completeTask, dismissTask, getHeroSummary, getOverdue, getTasksForDate, reopenTask, rescheduleTask, type Task } from '../../db/taskService';
import { bump, useDataVersion } from '../../state/dataVersion';

export function TodayScreen() {
  const { colors } = useTheme();
  const version = useDataVersion();
  const today = todayISO();
  const [selected, setSelected] = useState(today);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [overdue, setOverdue] = useState<Task[]>([]);
  const [hero, setHero] = useState<Awaited<ReturnType<typeof getHeroSummary>> | null>(null);
  const [showDone, setShowDone] = useState(false);
  const [adding, setAdding] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [tk, od, h] = await Promise.all([getTasksForDate(selected), getOverdue(today), getHeroSummary()]);
        if (!alive) return;
        setTasks(tk);
        setOverdue(od);
        setHero(h);
        setError(null);
      } catch (e: any) {
        if (alive) setError(String(e?.message ?? e));
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [selected, version, today]);

  const toggle = useCallback(async (task: Task) => {
    if (task.status === 'done') await reopenTask(task.id);
    else await completeTask(task.id);
    bump();
  }, []);

  const week = useMemo(() => {
    const start = startOfWeek(selected);
    return Array.from({ length: 7 }, (_, i) => addDays(start, i));
  }, [selected]);

  const open = tasks.filter((x) => x.status === 'open');
  const done = tasks.filter((x) => x.status === 'done');
  const timed = open.filter((x) => x.scheduledTime);
  const untimed = open.filter((x) => !x.scheduledTime);
  const pct = completionPercent(done.length, tasks.length);

  const dateLabel = new Date(selected + 'T00:00:00').toLocaleDateString(locale(), { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }} edges={['top']}>
      <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Header: compact, hero is a small presence only */}
        <View style={{ padding: spacing.lg, gap: spacing.sm }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flex: 1 }}>
              <Txt bold size={22}>{dateLabel}</Txt>
              <Txt muted size={13}>{t('greeting')}</Txt>
            </View>
            {hero && (
              <View style={{ alignItems: 'flex-end', gap: 4, minWidth: 96 }}>
                <View style={{ flexDirection: 'row', gap: spacing.sm }}>
                  <Txt bold size={13}>{t('level')} {hero.level}</Txt>
                  <Txt size={13} color={colors.gold} bold>● {hero.realCoins}</Txt>
                </View>
                <View style={{ width: 96 }}><ProgressBar value={hero.progress} color={colors.gold} /></View>
              </View>
            )}
          </View>
        </View>

        {/* Weekly date selector */}
        <View style={{ flexDirection: 'row', paddingHorizontal: spacing.md, gap: 6 }}>
          {week.map((d) => {
            const sel = d === selected;
            const dt = new Date(d + 'T00:00:00');
            return (
              <Pressable key={d} onPress={() => setSelected(d)} style={{ flex: 1, alignItems: 'center', paddingVertical: spacing.sm, borderRadius: radius.md, backgroundColor: sel ? colors.primary : 'transparent', borderWidth: d === today && !sel ? 1 : 0, borderColor: colors.primary }}>
                <Txt size={11} color={sel ? colors.primaryText : colors.textMuted}>{dt.toLocaleDateString(locale(), { weekday: 'short' })}</Txt>
                <Txt bold color={sel ? colors.primaryText : colors.text}>{dt.getDate()}</Txt>
              </Pressable>
            );
          })}
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: spacing.lg, paddingTop: spacing.sm }}>
          <Pressable onPress={() => setSelected(addDays(selected, -7))}><Txt muted size={13}>‹</Txt></Pressable>
          <Pressable onPress={() => setSelected(today)}><Txt color={colors.primary} size={13}>{t('today')}</Txt></Pressable>
          <Pressable onPress={() => setSelected(addDays(selected, 7))}><Txt muted size={13}>›</Txt></Pressable>
        </View>

        {/* Daily summary */}
        <Card style={{ margin: spacing.lg, gap: spacing.sm }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
            <Stat label={t('total')} value={tasks.length} />
            <Stat label={t('done')} value={done.length} />
            <Stat label={t('remaining')} value={open.length} />
            <Stat label="%" value={pct} />
          </View>
          <ProgressBar value={pct / 100} />
        </Card>

        {error ? <Txt color={colors.danger} style={{ padding: spacing.lg }}>{error}</Txt> : null}

        {overdue.length > 0 && selected === today && (
          <Section title={`${t('overdue')} (${overdue.length})`}>
            {overdue.map((o) => (
              <View key={o.id}>
                <TaskRow task={o} onToggle={toggle} />
                <View style={{ flexDirection: 'row', gap: spacing.lg, paddingHorizontal: spacing.lg + 38, paddingBottom: spacing.sm }}>
                  <Pressable onPress={async () => { await rescheduleTask(o.id, addDays(today, 1)); bump(); }}><Txt size={12} color={colors.primary}>{t('reschedule')}</Txt></Pressable>
                  <Pressable onPress={async () => { await dismissTask(o.id); bump(); }}><Txt size={12} muted>{t('dismiss')}</Txt></Pressable>
                </View>
              </View>
            ))}
          </Section>
        )}

        {!loading && tasks.length === 0 ? <EmptyState title={t('emptyDay')} hint={t('emptyHint')} /> : null}

        {timed.length > 0 && <Section title={t('today')}>{timed.map((x) => <TaskRow key={x.id} task={x} onToggle={toggle} />)}</Section>}
        {untimed.length > 0 && <Section title={t('noTime')}>{untimed.map((x) => <TaskRow key={x.id} task={x} onToggle={toggle} />)}</Section>}

        {done.length > 0 && (
          <View>
            <Pressable onPress={() => setShowDone(!showDone)} style={{ paddingHorizontal: spacing.lg, paddingVertical: spacing.md }}>
              <Txt muted bold size={13}>{showDone ? '▾' : '▸'} {t('completed')} ({done.length})</Txt>
            </Pressable>
            {showDone && done.map((x) => <TaskRow key={x.id} task={x} onToggle={toggle} />)}
          </View>
        )}
      </ScrollView>

      <Fab onPress={() => setAdding(true)} />
      <AddTaskSheet visible={adding} date={selected} onClose={() => setAdding(false)} />
    </SafeAreaView>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <View style={{ alignItems: 'center' }}>
      <Txt bold size={20}>{value}</Txt>
      <Txt muted size={12}>{label}</Txt>
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={{ marginTop: spacing.sm }}>
      <Txt muted bold size={13} style={{ paddingHorizontal: spacing.lg, paddingBottom: 2 }}>{title}</Txt>
      {children}
    </View>
  );
}
