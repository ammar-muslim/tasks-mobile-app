import React from 'react';
import { View } from 'react-native';
import { Txt } from '../ui/components';
import { useTheme } from '../theme';
import { t } from '../i18n';

/** Honest stand-in for tabs that belong to later stages. Not a fake screen: it says it is not built. */
export function NotBuilt({ title, stage }: { title: string; stage: number }) {
  const { colors } = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', gap: 6 }}>
      <Txt bold size={20}>{title}</Txt>
      <Txt muted>{t('comingSoon')} (Stage {stage})</Txt>
    </View>
  );
}
