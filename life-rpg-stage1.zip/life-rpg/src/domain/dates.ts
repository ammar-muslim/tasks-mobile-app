import type { ISODate } from './types.ts';

// All date math is done on 'YYYY-MM-DD' strings in UTC so the device timezone never shifts a day.

export function parseISO(d: ISODate): Date {
  const [y, m, day] = d.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, day));
}

export function toISO(date: Date): ISODate {
  return date.toISOString().slice(0, 10);
}

/** Today's local calendar date as ISO (uses device local time, not UTC). */
export function todayISO(now: Date = new Date()): ISODate {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDays(d: ISODate, n: number): ISODate {
  const date = parseISO(d);
  date.setUTCDate(date.getUTCDate() + n);
  return toISO(date);
}

export function weekday(d: ISODate): number {
  return parseISO(d).getUTCDay();
}

export function daysInMonth(year: number, month1: number): number {
  return new Date(Date.UTC(year, month1, 0)).getUTCDate();
}

/** Add months, clamping the day (Jan 31 + 1 month = Feb 28/29). */
export function addMonths(d: ISODate, n: number, anchorDay?: number): ISODate {
  const date = parseISO(d);
  const targetDay = anchorDay ?? date.getUTCDate();
  const total = date.getUTCFullYear() * 12 + date.getUTCMonth() + n;
  const y = Math.floor(total / 12);
  const m = total % 12;
  const day = Math.min(targetDay, daysInMonth(y, m + 1));
  return toISO(new Date(Date.UTC(y, m, day)));
}

export function startOfWeek(d: ISODate, weekStartsOn = 6): ISODate {
  // Default Saturday (Egypt). 0 = Sunday ... 6 = Saturday
  const diff = (weekday(d) - weekStartsOn + 7) % 7;
  return addDays(d, -diff);
}

export function daysBetween(a: ISODate, b: ISODate): number {
  return Math.round((parseISO(b).getTime() - parseISO(a).getTime()) / 86400000);
}
