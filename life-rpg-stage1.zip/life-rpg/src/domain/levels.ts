/** XP needed to go from level n to n+1. Gentle curve so early levels come fast. */
export function xpToNextLevel(level: number): number {
  return Math.round(80 + 20 * level + 5 * level * level);
}

/** Cumulative XP required to REACH `level` (level 1 = 0 XP). */
export function totalXpForLevel(level: number): number {
  let sum = 0;
  for (let l = 1; l < level; l++) sum += xpToNextLevel(l);
  return sum;
}

export interface LevelInfo {
  level: number;
  currentXp: number; // XP inside the current level
  xpForNext: number; // XP needed to finish current level
  progress: number; // 0..1
}

export function levelFromTotalXp(totalXp: number): LevelInfo {
  let level = 1;
  let remaining = Math.max(0, Math.floor(totalXp));
  while (remaining >= xpToNextLevel(level)) {
    remaining -= xpToNextLevel(level);
    level++;
  }
  const xpForNext = xpToNextLevel(level);
  return { level, currentXp: remaining, xpForNext, progress: remaining / xpForNext };
}

/** Visual stages of the hero. Index = stage id. */
export const HERO_STAGES = [
  { stage: 0, minLevel: 1, key: 'traveler' },
  { stage: 1, minLevel: 5, key: 'squire' },
  { stage: 2, minLevel: 10, key: 'knight' },
  { stage: 3, minLevel: 20, key: 'champion' },
] as const;

export function heroStageForLevel(level: number): number {
  let stage = 0;
  for (const s of HERO_STAGES) if (level >= s.minLevel) stage = s.stage;
  return stage;
}
