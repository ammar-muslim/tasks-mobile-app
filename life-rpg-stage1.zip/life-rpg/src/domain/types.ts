export type ISODate = string; // 'YYYY-MM-DD'

export type Priority = 0 | 1 | 2 | 3; // none, low, medium, high
export type Difficulty = 1 | 2 | 3 | 4 | 5;

export type RecurrenceFreq = 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface RecurrenceRule {
  freq: RecurrenceFreq;
  /** every N days/weeks/months/years (>= 1) */
  interval: number;
  /** weekly only: 0 = Sunday ... 6 = Saturday. Empty/undefined = same weekday as the source date */
  weekdays?: number[];
  /** inclusive end date; undefined = unlimited */
  endDate?: ISODate;
}

export type CurrencyType = 'xp' | 'equipment' | 'real';

export interface RewardAmounts {
  xp: number;
  equipmentCoins: number;
  realCoins: number;
}

export type HabitType = 'binary' | 'measurable' | 'frequency';
