import type { Difficulty, HabitType, Priority, RewardAmounts } from './types.ts';

/** Tunable economy. Stored in settings later; defaults are a simple balanced config. */
export interface RewardConfig {
  baseXp: number;
  xpPerDifficulty: number;
  xpPerPriority: number;
  /** extra XP per 30 minutes of estimated effort, capped */
  xpPerHalfHour: number;
  maxEffortXp: number;
  equipmentCoinRatio: number; // coins = xp * ratio
  realCoinRatio: number; // real-life coins = xp * ratio
  habitBaseXp: number;
  habitFullTargetBonus: number;
}

export const DEFAULT_REWARD_CONFIG: RewardConfig = {
  baseXp: 10,
  xpPerDifficulty: 5,
  xpPerPriority: 3,
  xpPerHalfHour: 2,
  maxEffortXp: 12,
  equipmentCoinRatio: 0.5,
  realCoinRatio: 0.4,
  habitBaseXp: 8,
  habitFullTargetBonus: 4,
};

export interface TaskRewardInput {
  priority: Priority;
  difficulty: Difficulty;
  estimatedMinutes?: number | null;
}

export function computeTaskReward(input: TaskRewardInput, cfg: RewardConfig = DEFAULT_REWARD_CONFIG): RewardAmounts {
  const effort = Math.min(cfg.maxEffortXp, Math.floor((input.estimatedMinutes ?? 0) / 30) * cfg.xpPerHalfHour);
  const xp = cfg.baseXp + (input.difficulty - 1) * cfg.xpPerDifficulty + input.priority * cfg.xpPerPriority + effort;
  return {
    xp,
    equipmentCoins: Math.round(xp * cfg.equipmentCoinRatio),
    realCoins: Math.round(xp * cfg.realCoinRatio),
  };
}

export interface HabitRewardInput {
  type: HabitType;
  difficulty?: Difficulty;
  /** for measurable habits: progress / target when the log was completed */
  completionRatio?: number;
}

/** Habits are rewarded separately from tasks (smaller, consistent amounts). */
export function computeHabitReward(input: HabitRewardInput, cfg: RewardConfig = DEFAULT_REWARD_CONFIG): RewardAmounts {
  const diff = input.difficulty ?? 1;
  const xp = cfg.habitBaseXp + (diff - 1) * 2 + ((input.completionRatio ?? 1) >= 1 ? cfg.habitFullTargetBonus : 0);
  return {
    xp,
    equipmentCoins: Math.round(xp * cfg.equipmentCoinRatio),
    realCoins: Math.round(xp * cfg.realCoinRatio),
  };
}

/**
 * Idempotency key for a reward. The DB has a UNIQUE index on this value, so a task
 * (or a specific occurrence of a recurring task / a habit on a specific day) can
 * only ever pay out once, no matter how many times it is re-opened and re-completed.
 */
export function rewardKey(entity: 'task' | 'habit', id: string, occurrence: string): string {
  return `${entity}:${id}:${occurrence}`;
}

/** Whether `balance` can pay for a reward of `cost`. Real-life coins only. */
export function canAfford(balance: number, cost: number): boolean {
  return Number.isInteger(cost) && cost > 0 && balance >= cost;
}
