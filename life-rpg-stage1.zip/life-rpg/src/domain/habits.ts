import { addDays, startOfWeek } from './dates.ts';
import type { ISODate } from './types.ts';

/**
 * Forgiving streak: counts consecutive completed days ending today OR yesterday
 * (so the streak is not "lost" before the day is over). Past history is never erased:
 * longestStreak is computed from all logs.
 */
export function computeStreaks(completedDates: Iterable<ISODate>, today: ISODate) {
  const set = new Set(completedDates);
  let current = 0;
  let cursor = set.has(today) ? today : addDays(today, -1);
  while (set.has(cursor)) {
    current++;
    cursor = addDays(cursor, -1);
  }

  const sorted = [...set].sort();
  let longest = 0;
  let run = 0;
  let prev: ISODate | null = null;
  for (const d of sorted) {
    run = prev && addDays(prev, 1) === d ? run + 1 : 1;
    if (run > longest) longest = run;
    prev = d;
  }
  return { current, longest };
}

/** Count of completed days inside the week containing `date`. */
export function weeklyCount(completedDates: Iterable<ISODate>, date: ISODate, weekStartsOn = 6): number {
  const start = startOfWeek(date, weekStartsOn);
  const end = addDays(start, 6);
  let n = 0;
  for (const d of completedDates) if (d >= start && d <= end) n++;
  return n;
}

export function completionPercent(done: number, total: number): number {
  return total <= 0 ? 0 : Math.round((done / total) * 100);
}
