import { addDays, addMonths, parseISO, weekday } from './dates.ts';
import type { ISODate, RecurrenceRule } from './types.ts';

/**
 * Next occurrence strictly AFTER `from`. Returns null when the rule has ended.
 * `anchor` is the original start date, used so monthly rules on the 31st
 * keep returning to the 31st after a short month.
 */
export function nextOccurrence(rule: RecurrenceRule, from: ISODate, anchor: ISODate = from): ISODate | null {
  const interval = Math.max(1, Math.floor(rule.interval || 1));
  let next: ISODate;

  switch (rule.freq) {
    case 'daily':
      next = addDays(from, interval);
      break;
    case 'weekly': {
      const days = rule.weekdays && rule.weekdays.length ? [...new Set(rule.weekdays)].sort((a, b) => a - b) : [weekday(anchor)];
      next = nextWeekly(from, days, interval);
      break;
    }
    case 'monthly':
      next = addMonths(from, interval, parseISO(anchor).getUTCDate());
      break;
    case 'yearly':
      next = addMonths(from, 12 * interval, parseISO(anchor).getUTCDate());
      break;
  }

  if (rule.endDate && next > rule.endDate) return null;
  return next;
}

function nextWeekly(from: ISODate, days: number[], interval: number): ISODate {
  const current = weekday(from);
  // Later weekday in the same week (week = Sun..Sat)
  const later = days.find((d) => d > current);
  if (later !== undefined) return addDays(from, later - current);
  // Otherwise jump `interval` weeks forward to the first selected weekday
  const startOfThisWeek = addDays(from, -current);
  return addDays(startOfThisWeek, 7 * interval + days[0]);
}

/** All occurrences within [rangeStart, rangeEnd], including the base date. Used by calendar views. */
export function occurrencesInRange(
  rule: RecurrenceRule,
  base: ISODate,
  rangeStart: ISODate,
  rangeEnd: ISODate,
  limit = 400,
): ISODate[] {
  const out: ISODate[] = [];
  let cur: ISODate | null = base;
  let guard = 0;
  while (cur && cur <= rangeEnd && guard++ < limit * 4) {
    if (cur >= rangeStart) out.push(cur);
    cur = nextOccurrence(rule, cur, base);
    if (out.length >= limit) break;
  }
  return out;
}
