import { test } from 'node:test';
import assert from 'node:assert/strict';
import { nextOccurrence, occurrencesInRange } from '../recurrence.ts';
import { levelFromTotalXp, totalXpForLevel, heroStageForLevel } from '../levels.ts';
import { computeTaskReward, computeHabitReward, rewardKey, canAfford } from '../rewards.ts';
import { computeStreaks, weeklyCount } from '../habits.ts';
import { evaluateAchievements } from '../achievements.ts';
import { addMonths, startOfWeek } from '../dates.ts';

test('daily / interval recurrence', () => {
  assert.equal(nextOccurrence({ freq: 'daily', interval: 1 }, '2026-11-14'), '2026-11-15');
  assert.equal(nextOccurrence({ freq: 'daily', interval: 3 }, '2026-11-14'), '2026-11-17');
});

test('weekly with selected weekdays (Sat=6, Mon=1)', () => {
  const rule = { freq: 'weekly' as const, interval: 1, weekdays: [1, 6] };
  // 2026-11-14 is a Saturday -> next is Monday 16th
  assert.equal(nextOccurrence(rule, '2026-11-14'), '2026-11-16');
  // Monday -> Saturday same week
  assert.equal(nextOccurrence(rule, '2026-11-16'), '2026-11-21');
});

test('weekly every 2 weeks jumps correctly', () => {
  const rule = { freq: 'weekly' as const, interval: 2, weekdays: [6] };
  assert.equal(nextOccurrence(rule, '2026-11-14'), '2026-11-28');
});

test('monthly clamps short months and returns to anchor day', () => {
  const rule = { freq: 'monthly' as const, interval: 1 };
  const feb = nextOccurrence(rule, '2026-01-31', '2026-01-31');
  assert.equal(feb, '2026-02-28');
  assert.equal(nextOccurrence(rule, feb!, '2026-01-31'), '2026-03-31');
});

test('yearly and leap day', () => {
  assert.equal(nextOccurrence({ freq: 'yearly', interval: 1 }, '2026-11-14'), '2027-11-14');
  assert.equal(addMonths('2024-02-29', 12, 29), '2025-02-28');
});

test('end date stops recurrence', () => {
  const rule = { freq: 'daily' as const, interval: 1, endDate: '2026-11-15' };
  assert.equal(nextOccurrence(rule, '2026-11-14'), '2026-11-15');
  assert.equal(nextOccurrence(rule, '2026-11-15'), null);
});

test('occurrencesInRange has no duplicates and is sorted', () => {
  const list = occurrencesInRange({ freq: 'weekly', interval: 1, weekdays: [0, 3] }, '2026-11-01', '2026-11-01', '2026-11-30');
  assert.equal(new Set(list).size, list.length);
  assert.deepEqual(list, [...list].sort());
  assert.ok(list.every((d) => d >= '2026-11-01' && d <= '2026-11-30'));
});

test('levels are consistent', () => {
  assert.equal(levelFromTotalXp(0).level, 1);
  const need = totalXpForLevel(5);
  assert.equal(levelFromTotalXp(need).level, 5);
  assert.equal(levelFromTotalXp(need - 1).level, 4);
  const info = levelFromTotalXp(need + 10);
  assert.equal(info.currentXp, 10);
  assert.ok(info.progress > 0 && info.progress < 1);
});

test('hero stages', () => {
  assert.equal(heroStageForLevel(1), 0);
  assert.equal(heroStageForLevel(5), 1);
  assert.equal(heroStageForLevel(19), 2);
  assert.equal(heroStageForLevel(50), 3);
});

test('task reward scales with difficulty/priority and keeps 3 separate amounts', () => {
  const easy = computeTaskReward({ priority: 0, difficulty: 1 });
  const hard = computeTaskReward({ priority: 3, difficulty: 5, estimatedMinutes: 90 });
  assert.ok(hard.xp > easy.xp);
  assert.ok(hard.equipmentCoins > 0 && hard.realCoins > 0);
  assert.equal(easy.xp, 10);
});

test('habit rewards are computed separately and are smaller than hard tasks', () => {
  const h = computeHabitReward({ type: 'binary' });
  const t = computeTaskReward({ priority: 3, difficulty: 5 });
  assert.ok(h.xp < t.xp);
});

test('reward keys are stable per occurrence', () => {
  assert.equal(rewardKey('task', 'a', '2026-11-14'), 'task:a:2026-11-14');
  assert.notEqual(rewardKey('task', 'a', '2026-11-14'), rewardKey('task', 'a', '2026-11-15'));
});

test('canAfford', () => {
  assert.equal(canAfford(50, 50), true);
  assert.equal(canAfford(49, 50), false);
  assert.equal(canAfford(100, 0), false);
});

test('streaks are forgiving until the day ends and history is kept', () => {
  const logs = ['2026-11-10', '2026-11-11', '2026-11-12', '2026-11-13'];
  assert.deepEqual(computeStreaks(logs, '2026-11-14'), { current: 4, longest: 4 });
  // missed two days: current resets but longest is preserved
  assert.deepEqual(computeStreaks(logs, '2026-11-16'), { current: 0, longest: 4 });
});

test('weekly count (week starts Saturday)', () => {
  assert.equal(startOfWeek('2026-11-14'), '2026-11-14');
  assert.equal(weeklyCount(['2026-11-13', '2026-11-14', '2026-11-16', '2026-11-20', '2026-11-21'], '2026-11-17'), 3);
});

test('achievements only unlock once', () => {
  const stats = { tasksCompleted: 10, level: 1, totalXp: 5, bestHabitStreak: 0, habitCheckins: 0 };
  const first = evaluateAchievements(stats, new Set());
  assert.deepEqual(first.sort(), ['tasks_1', 'tasks_10']);
  assert.deepEqual(evaluateAchievements(stats, new Set(first)), []);
});
