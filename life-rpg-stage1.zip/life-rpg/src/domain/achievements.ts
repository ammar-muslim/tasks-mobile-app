export type AchievementMetric = 'tasksCompleted' | 'level' | 'totalXp' | 'bestHabitStreak' | 'habitCheckins';

export interface AchievementDef {
  id: string;
  metric: AchievementMetric;
  threshold: number;
  title: { ar: string; en: string };
  description: { ar: string; en: string };
}

export interface AchievementStats {
  tasksCompleted: number;
  level: number;
  totalXp: number;
  bestHabitStreak: number;
  habitCheckins: number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'tasks_1', metric: 'tasksCompleted', threshold: 1, title: { ar: 'البداية', en: 'First Step' }, description: { ar: 'أنجز أول مهمة', en: 'Complete your first task' } },
  { id: 'tasks_10', metric: 'tasksCompleted', threshold: 10, title: { ar: 'ماشي كويس', en: 'Getting Going' }, description: { ar: 'أنجز ١٠ مهام', en: 'Complete 10 tasks' } },
  { id: 'tasks_50', metric: 'tasksCompleted', threshold: 50, title: { ar: 'منجز', en: 'Achiever' }, description: { ar: 'أنجز ٥٠ مهمة', en: 'Complete 50 tasks' } },
  { id: 'tasks_100', metric: 'tasksCompleted', threshold: 100, title: { ar: 'ماكينة', en: 'Powerhouse' }, description: { ar: 'أنجز ١٠٠ مهمة', en: 'Complete 100 tasks' } },
  { id: 'level_5', metric: 'level', threshold: 5, title: { ar: 'مستوى ٥', en: 'Level 5' }, description: { ar: 'وصّل البطل للمستوى ٥', en: 'Reach level 5' } },
  { id: 'level_10', metric: 'level', threshold: 10, title: { ar: 'مستوى ١٠', en: 'Level 10' }, description: { ar: 'وصّل البطل للمستوى ١٠', en: 'Reach level 10' } },
  { id: 'xp_1000', metric: 'totalXp', threshold: 1000, title: { ar: '١٠٠٠ خبرة', en: '1,000 XP' }, description: { ar: 'اجمع ١٠٠٠ نقطة خبرة', en: 'Earn 1,000 total XP' } },
  { id: 'streak_7', metric: 'bestHabitStreak', threshold: 7, title: { ar: 'أسبوع ثابت', en: 'Steady Week' }, description: { ar: 'حافظ على عادة ٧ أيام ورا بعض', en: 'Keep a habit for 7 days in a row' } },
  { id: 'habits_100', metric: 'habitCheckins', threshold: 100, title: { ar: '١٠٠ تسجيل', en: '100 Check-ins' }, description: { ar: 'سجّل ١٠٠ مرة في العادات', en: 'Log 100 habit check-ins' } },
];

/** Returns ids of achievements whose threshold is met and that are not already unlocked. */
export function evaluateAchievements(stats: AchievementStats, alreadyUnlocked: Set<string>): string[] {
  return ACHIEVEMENTS.filter((a) => !alreadyUnlocked.has(a.id) && stats[a.metric] >= a.threshold).map((a) => a.id);
}
