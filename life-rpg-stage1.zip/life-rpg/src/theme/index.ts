import { useColorScheme } from 'react-native';

const palette = {
  light: {
    bg: '#F6F4EE',
    surface: '#FFFFFF',
    surfaceAlt: '#EEEBE2',
    text: '#1F2A24',
    textMuted: '#6B766F',
    border: '#E2DED2',
    primary: '#2F6F57', // muted forest emerald
    primaryText: '#FFFFFF',
    gold: '#C79A3B', // warm gold accent
    danger: '#B5524A',
    prio: ['#B8BEB9', '#5E9C86', '#D1A23F', '#C4574E'],
  },
  dark: {
    bg: '#141A17',
    surface: '#1D2520',
    surfaceAlt: '#26302A',
    text: '#EAEFEA',
    textMuted: '#9AA79F',
    border: '#2E3932',
    primary: '#4FA382',
    primaryText: '#0E1511',
    gold: '#DDB257',
    danger: '#D9776E',
    prio: ['#5C6760', '#6FB59B', '#DDB257', '#E0786F'],
  },
};

export type Colors = typeof palette.light;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 };
export const radius = { sm: 8, md: 12, lg: 20, pill: 999 };

export const fonts = {
  // Swap for Alexandria / IBM Plex Sans Arabic once the font packages are added (see README).
  regular: undefined as string | undefined,
  bold: undefined as string | undefined,
};

export function useTheme(): { colors: Colors; dark: boolean } {
  const scheme = useColorScheme();
  const dark = scheme === 'dark';
  return { colors: dark ? palette.dark : palette.light, dark };
}
