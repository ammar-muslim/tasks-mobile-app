import React from 'react';
import { Pressable, StyleSheet, Text, View, type ViewStyle } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { radius, spacing, useTheme } from '../theme';

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  const { colors } = useTheme();
  return <View style={[{ backgroundColor: colors.surface, borderRadius: radius.md, borderColor: colors.border, borderWidth: StyleSheet.hairlineWidth, padding: spacing.md }, style]}>{children}</View>;
}

export function Txt({ children, muted, bold, size = 15, color, style }: { children: React.ReactNode; muted?: boolean; bold?: boolean; size?: number; color?: string; style?: any }) {
  const { colors } = useTheme();
  return <Text style={[{ color: color ?? (muted ? colors.textMuted : colors.text), fontSize: size, fontWeight: bold ? '700' : '400' }, style]}>{children}</Text>;
}

export function ProgressBar({ value, color }: { value: number; color?: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ height: 6, borderRadius: radius.pill, backgroundColor: colors.surfaceAlt, overflow: 'hidden' }}>
      <View style={{ width: `${Math.round(Math.min(1, Math.max(0, value)) * 100)}%`, height: '100%', backgroundColor: color ?? colors.primary }} />
    </View>
  );
}

export function Checkbox({ checked, onPress, color }: { checked: boolean; onPress: () => void; color?: string }) {
  const { colors } = useTheme();
  const c = color ?? colors.primary;
  return (
    <Pressable onPress={onPress} hitSlop={10} accessibilityRole="checkbox" accessibilityState={{ checked }}
      style={{ width: 26, height: 26, borderRadius: 13, borderWidth: 2, borderColor: checked ? c : colors.border, backgroundColor: checked ? c : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
      {checked && <Feather name="check" size={16} color={colors.primaryText} />}
    </Pressable>
  );
}

export function Fab({ onPress }: { onPress: () => void }) {
  const { colors } = useTheme();
  return (
    <Pressable onPress={onPress} accessibilityLabel="add"
      style={{ position: 'absolute', end: 20, bottom: 20, width: 56, height: 56, borderRadius: 28, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', elevation: 4 }}>
      <Feather name="plus" size={28} color={colors.primaryText} />
    </Pressable>
  );
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <View style={{ alignItems: 'center', padding: spacing.xl * 2 }}>
      <Feather name="sun" size={36} color="#9AA79F" />
      <Txt bold style={{ marginTop: spacing.md }}>{title}</Txt>
      {hint ? <Txt muted size={13} style={{ marginTop: 4 }}>{hint}</Txt> : null}
    </View>
  );
}
