import { I18nManager } from 'react-native';

export type Lang = 'ar' | 'en';

const dict = {
  ar: {
    today: 'اليوم', tasks: 'المهام', habits: 'العادات', reminders: 'التذكيرات', hero: 'البطل',
    greeting: 'يلا نخلّص النهاردة', total: 'الإجمالي', done: 'خلص', remaining: 'باقي',
    noTime: 'من غير وقت', completed: 'المكتملة', overdue: 'متأخرة', addTask: 'مهمة جديدة',
    taskTitle: 'عنوان المهمة', save: 'حفظ', cancel: 'إلغاء', emptyDay: 'مفيش مهام في اليوم ده',
    emptyHint: 'اضغط + وأضف أول مهمة', tomorrow: 'بكرة', reschedule: 'انقلها لبكرة', dismiss: 'تجاهل',
    level: 'مستوى', priority: 'الأولوية', none: 'بدون', low: 'منخفضة', medium: 'متوسطة', high: 'عالية',
    comingSoon: 'الشاشة دي لسه مابتتنفذش',
  },
  en: {
    today: 'Today', tasks: 'Tasks', habits: 'Habits', reminders: 'Reminders', hero: 'Hero',
    greeting: "Let's get today done", total: 'Total', done: 'Done', remaining: 'Left',
    noTime: 'No time', completed: 'Completed', overdue: 'Overdue', addTask: 'New task',
    taskTitle: 'Task title', save: 'Save', cancel: 'Cancel', emptyDay: 'No tasks for this day',
    emptyHint: 'Tap + to add your first task', tomorrow: 'Tomorrow', reschedule: 'Move to tomorrow', dismiss: 'Dismiss',
    level: 'Level', priority: 'Priority', none: 'None', low: 'Low', medium: 'Medium', high: 'High',
    comingSoon: 'This screen is not built yet',
  },
} as const;

export type StringKey = keyof (typeof dict)['ar'];

let current: Lang = 'ar';

export function setLanguage(lang: Lang) {
  current = lang;
  const rtl = lang === 'ar';
  if (I18nManager.isRTL !== rtl) {
    I18nManager.allowRTL(rtl);
    I18nManager.forceRTL(rtl); // takes effect after an app reload
  }
}

export function t(key: StringKey): string {
  return dict[current][key];
}

export function getLanguage(): Lang {
  return current;
}

export function locale(): string {
  return current === 'ar' ? 'ar-EG' : 'en-US';
}
