import { useEffect, useState } from 'react';

// Tiny pub/sub: any mutation calls bump(); screens re-query when the version changes.
const listeners = new Set<() => void>();
let version = 0;

export function bump() {
  version++;
  listeners.forEach((l) => l());
}

export function useDataVersion(): number {
  const [v, setV] = useState(version);
  useEffect(() => {
    const l = () => setV(version);
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);
  return v;
}
