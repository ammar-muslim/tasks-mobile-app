import * as SQLite from 'expo-sqlite';
import { MIGRATIONS } from './schema';

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb(): Promise<SQLite.SQLiteDatabase> {
  if (!dbPromise) dbPromise = init();
  return dbPromise;
}

async function init() {
  const db = await SQLite.openDatabaseAsync('liferpg.db');
  await db.execAsync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  const row = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
  const current = row?.user_version ?? 0;
  for (let v = current; v < MIGRATIONS.length; v++) {
    await db.withTransactionAsync(async () => {
      await db.execAsync(MIGRATIONS[v]);
    });
    await db.execAsync(`PRAGMA user_version = ${v + 1}`);
  }
  await seedIfEmpty(db);
  return db;
}

export function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

async function seedIfEmpty(db: SQLite.SQLiteDatabase) {
  const u = await db.getFirstAsync<{ c: number }>('SELECT COUNT(*) AS c FROM user');
  if ((u?.c ?? 0) > 0) return;
  await db.withTransactionAsync(async () => {
    await db.runAsync('INSERT INTO user (id, name, language, theme) VALUES (?, ?, ?, ?)', ['me', 'عمار', 'ar', 'system']);
    await db.runAsync('INSERT INTO character (id, name, total_xp, appearance_stage) VALUES (?, ?, 0, 0)', ['hero', 'عمار']);
    await db.runAsync('INSERT INTO reward_wallet (id, equipment_coins, real_coins) VALUES (1, 0, 0)');

    const skills: [string, string, string][] = [
      ['programming', 'البرمجة', 'code'],
      ['reading', 'القراءة', 'book-open'],
      ['fitness', 'اللياقة', 'activity'],
      ['language', 'تعلم اللغات', 'globe'],
      ['knowledge', 'المعرفة', 'bookmark'],
    ];
    for (const [id, name, icon] of skills) await db.runAsync('INSERT INTO skill (id, name, icon) VALUES (?, ?, ?)', [id, name, icon]);

    const attrs: [string, string, string][] = [
      ['strength', 'القوة', 'shield'],
      ['intelligence', 'الذكاء', 'cpu'],
      ['discipline', 'الانضباط', 'target'],
      ['vitality', 'الحيوية', 'heart'],
      ['creativity', 'الإبداع', 'feather'],
    ];
    for (const [id, name, icon] of attrs) await db.runAsync('INSERT INTO attribute (id, name, icon) VALUES (?, ?, ?)', [id, name, icon]);
  });
}
