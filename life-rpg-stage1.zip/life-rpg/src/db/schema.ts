export const SCHEMA_VERSION = 1;

/**
 * Local SQLite schema. Three reward currencies stay separate (xp / equipment / real)
 * and every payout is a row in reward_transactions with a UNIQUE reward_key,
 * which is what guarantees "reward only once".
 */
export const MIGRATIONS: string[] = [
  `
  CREATE TABLE IF NOT EXISTS user (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    language TEXT NOT NULL DEFAULT 'ar',
    theme TEXT NOT NULL DEFAULT 'system',
    timezone TEXT,
    preferences TEXT NOT NULL DEFAULT '{}'
  );

  CREATE TABLE IF NOT EXISTS task_list (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    color TEXT NOT NULL DEFAULT '#2F6F57',
    icon TEXT NOT NULL DEFAULT 'list',
    sort_order INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS skill (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    icon TEXT NOT NULL DEFAULT 'star',
    xp INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS attribute (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    icon TEXT NOT NULL DEFAULT 'zap',
    value INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS task (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'open',            -- open | done | dismissed
    due_date TEXT,                                  -- YYYY-MM-DD
    scheduled_time TEXT,                            -- HH:mm
    priority INTEGER NOT NULL DEFAULT 0,
    list_id TEXT REFERENCES task_list(id) ON DELETE SET NULL,
    tags TEXT NOT NULL DEFAULT '[]',                -- JSON string[]
    recurrence_rule TEXT,                           -- JSON RecurrenceRule
    recurrence_anchor TEXT,                         -- original start date of the series
    parent_task_id TEXT REFERENCES task(id) ON DELETE CASCADE,
    difficulty INTEGER NOT NULL DEFAULT 1,
    estimated_minutes INTEGER,
    skill_id TEXT REFERENCES skill(id) ON DELETE SET NULL,
    attribute_id TEXT REFERENCES attribute(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL,
    completed_at TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_task_due ON task(due_date);
  CREATE INDEX IF NOT EXISTS idx_task_parent ON task(parent_task_id);

  CREATE TABLE IF NOT EXISTS habit (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    icon TEXT NOT NULL DEFAULT 'check-circle',
    category TEXT,
    type TEXT NOT NULL DEFAULT 'binary',            -- binary | measurable | frequency
    target REAL NOT NULL DEFAULT 1,
    unit TEXT,
    frequency TEXT NOT NULL DEFAULT 'daily',        -- daily | weekly
    weekly_target INTEGER,
    start_date TEXT NOT NULL,
    skill_id TEXT REFERENCES skill(id) ON DELETE SET NULL,
    attribute_id TEXT REFERENCES attribute(id) ON DELETE SET NULL,
    archived INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS habit_log (
    id TEXT PRIMARY KEY NOT NULL,
    habit_id TEXT NOT NULL REFERENCES habit(id) ON DELETE CASCADE,
    date TEXT NOT NULL,
    completed INTEGER NOT NULL DEFAULT 0,
    measured_value REAL NOT NULL DEFAULT 0,
    UNIQUE(habit_id, date)
  );

  CREATE TABLE IF NOT EXISTS reminder (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    date_time TEXT NOT NULL,                        -- ISO local datetime
    recurrence_rule TEXT,
    linked_entity_type TEXT,                        -- task | habit | null
    linked_entity_id TEXT,
    notification_id TEXT,
    status TEXT NOT NULL DEFAULT 'pending'          -- pending | done | dismissed
  );

  CREATE TABLE IF NOT EXISTS character (
    id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    total_xp INTEGER NOT NULL DEFAULT 0,
    appearance_stage INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS reward_wallet (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    equipment_coins INTEGER NOT NULL DEFAULT 0,
    real_coins INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS reward_transaction (
    id TEXT PRIMARY KEY NOT NULL,
    reward_key TEXT UNIQUE,                         -- idempotency key (NULL for spends)
    currency_type TEXT NOT NULL,                    -- xp | equipment | real
    amount INTEGER NOT NULL,                        -- negative = spend
    reason TEXT NOT NULL,
    related_entity_id TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS achievement_unlock (
    achievement_id TEXT PRIMARY KEY NOT NULL,
    unlocked_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS custom_reward (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    cost INTEGER NOT NULL,
    icon TEXT NOT NULL DEFAULT 'gift',
    redeemed_at TEXT
  );
  `,
];
