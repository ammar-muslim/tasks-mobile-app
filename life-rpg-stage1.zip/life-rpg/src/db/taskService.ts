import { getDb, uid } from './client';
import { computeTaskReward, rewardKey } from '../domain/rewards.ts';
import { nextOccurrence } from '../domain/recurrence.ts';
import { levelFromTotalXp, heroStageForLevel } from '../domain/levels.ts';
import { evaluateAchievements } from '../domain/achievements.ts';
import { todayISO } from '../domain/dates.ts';
import type { Difficulty, ISODate, Priority, RecurrenceRule } from '../domain/types.ts';

export interface Task {
  id: string;
  title: string;
  description: string | null;
  status: 'open' | 'done' | 'dismissed';
  dueDate: ISODate | null;
  scheduledTime: string | null;
  priority: Priority;
  listId: string | null;
  tags: string[];
  recurrence: RecurrenceRule | null;
  recurrenceAnchor: ISODate | null;
  parentTaskId: string | null;
  difficulty: Difficulty;
  estimatedMinutes: number | null;
  skillId: string | null;
  attributeId: string | null;
  createdAt: string;
  completedAt: string | null;
}

type Row = Record<string, any>;

function mapTask(r: Row): Task {
  return {
    id: r.id,
    title: r.title,
    description: r.description,
    status: r.status,
    dueDate: r.due_date,
    scheduledTime: r.scheduled_time,
    priority: r.priority,
    listId: r.list_id,
    tags: JSON.parse(r.tags || '[]'),
    recurrence: r.recurrence_rule ? JSON.parse(r.recurrence_rule) : null,
    recurrenceAnchor: r.recurrence_anchor,
    parentTaskId: r.parent_task_id,
    difficulty: r.difficulty,
    estimatedMinutes: r.estimated_minutes,
    skillId: r.skill_id,
    attributeId: r.attribute_id,
    createdAt: r.created_at,
    completedAt: r.completed_at,
  };
}

export type NewTask = Partial<Omit<Task, 'id' | 'createdAt' | 'completedAt' | 'status'>> & { title: string };

export async function createTask(input: NewTask): Promise<string> {
  const db = await getDb();
  const id = uid();
  const rule = input.recurrence ?? null;
  await db.runAsync(
    `INSERT INTO task (id, title, description, due_date, scheduled_time, priority, list_id, tags, recurrence_rule,
       recurrence_anchor, parent_task_id, difficulty, estimated_minutes, skill_id, attribute_id, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      id,
      input.title.trim(),
      input.description ?? null,
      input.dueDate ?? null,
      input.scheduledTime ?? null,
      input.priority ?? 0,
      input.listId ?? null,
      JSON.stringify(input.tags ?? []),
      rule ? JSON.stringify(rule) : null,
      rule ? input.dueDate ?? todayISO() : null,
      input.parentTaskId ?? null,
      input.difficulty ?? 1,
      input.estimatedMinutes ?? null,
      input.skillId ?? null,
      input.attributeId ?? null,
      new Date().toISOString(),
    ],
  );
  return id;
}

export async function getTasksForDate(date: ISODate): Promise<Task[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<Row>(
    `SELECT * FROM task WHERE parent_task_id IS NULL AND due_date = ? AND status != 'dismissed'
     ORDER BY (scheduled_time IS NULL), scheduled_time, priority DESC, created_at`,
    [date],
  );
  return rows.map(mapTask);
}

/** Overdue = open, due before `today`. Never penalised, just surfaced so they can be rescheduled/dismissed. */
export async function getOverdue(today: ISODate): Promise<Task[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<Row>(
    `SELECT * FROM task WHERE parent_task_id IS NULL AND status = 'open' AND due_date < ? ORDER BY due_date`,
    [today],
  );
  return rows.map(mapTask);
}

export async function rescheduleTask(id: string, date: ISODate | null) {
  const db = await getDb();
  await db.runAsync('UPDATE task SET due_date = ? WHERE id = ?', [date, id]);
}

export async function dismissTask(id: string) {
  const db = await getDb();
  await db.runAsync("UPDATE task SET status = 'dismissed' WHERE id = ?", [id]);
}

export async function deleteTask(id: string) {
  const db = await getDb();
  await db.runAsync('DELETE FROM task WHERE id = ?', [id]);
}

export interface CompletionResult {
  rewarded: boolean;
  xp: number;
  leveledUpTo: number | null;
  unlocked: string[];
}

/**
 * Completes a task in ONE transaction:
 *   mark done -> insert reward transactions (idempotent via UNIQUE reward_key) ->
 *   only if the key was newly inserted: update wallet, character XP, skill/attribute ->
 *   spawn next occurrence for recurring tasks -> evaluate achievements.
 * Re-tapping or reopening+completing again never pays twice.
 */
export async function completeTask(id: string): Promise<CompletionResult> {
  const db = await getDb();
  const result: CompletionResult = { rewarded: false, xp: 0, leveledUpTo: null, unlocked: [] };

  await db.withTransactionAsync(async () => {
    const row = await db.getFirstAsync<Row>('SELECT * FROM task WHERE id = ?', [id]);
    if (!row) return;
    const task = mapTask(row);
    if (task.status === 'done') return; // double tap: nothing to do

    const now = new Date().toISOString();
    await db.runAsync("UPDATE task SET status = 'done', completed_at = ? WHERE id = ?", [now, id]);

    const occurrence = task.dueDate ?? 'none';
    const reward = computeTaskReward({ priority: task.priority, difficulty: task.difficulty, estimatedMinutes: task.estimatedMinutes });
    const key = rewardKey('task', task.id, occurrence);

    // Only the XP row carries the idempotency key; if it already exists the whole payout is skipped.
    const ins = await db.runAsync(
      `INSERT OR IGNORE INTO reward_transaction (id, reward_key, currency_type, amount, reason, related_entity_id, created_at)
       VALUES (?, ?, 'xp', ?, ?, ?, ?)`,
      [uid(), key, reward.xp, `task:${task.title}`, task.id, now],
    );

    if (ins.changes > 0) {
      result.rewarded = true;
      result.xp = reward.xp;
      await db.runAsync(
        `INSERT INTO reward_transaction (id, reward_key, currency_type, amount, reason, related_entity_id, created_at)
         VALUES (?, ?, 'equipment', ?, ?, ?, ?), (?, ?, 'real', ?, ?, ?, ?)`,
        [uid(), `${key}:eq`, reward.equipmentCoins, `task:${task.title}`, task.id, now, uid(), `${key}:real`, reward.realCoins, `task:${task.title}`, task.id, now],
      );
      await db.runAsync('UPDATE reward_wallet SET equipment_coins = equipment_coins + ?, real_coins = real_coins + ? WHERE id = 1', [
        reward.equipmentCoins,
        reward.realCoins,
      ]);

      const ch = await db.getFirstAsync<{ total_xp: number }>("SELECT total_xp FROM character WHERE id = 'hero'");
      const before = levelFromTotalXp(ch?.total_xp ?? 0).level;
      const newTotal = (ch?.total_xp ?? 0) + reward.xp;
      const after = levelFromTotalXp(newTotal).level;
      await db.runAsync("UPDATE character SET total_xp = ?, appearance_stage = ? WHERE id = 'hero'", [newTotal, heroStageForLevel(after)]);
      if (after > before) result.leveledUpTo = after;

      if (task.skillId) await db.runAsync('UPDATE skill SET xp = xp + ? WHERE id = ?', [reward.xp, task.skillId]);
      if (task.attributeId) await db.runAsync('UPDATE attribute SET value = value + 1 WHERE id = ?', [task.attributeId]);
    }

    // Next occurrence of a recurring series (guarded against duplicates)
    if (task.recurrence && task.dueDate) {
      const next = nextOccurrence(task.recurrence, task.dueDate, task.recurrenceAnchor ?? task.dueDate);
      if (next) {
        const dup = await db.getFirstAsync<{ c: number }>(
          `SELECT COUNT(*) AS c FROM task WHERE title = ? AND due_date = ? AND recurrence_anchor = ? AND IFNULL(list_id,'') = IFNULL(?, '')`,
          [task.title, next, task.recurrenceAnchor ?? task.dueDate, task.listId],
        );
        if ((dup?.c ?? 0) === 0) {
          await db.runAsync(
            `INSERT INTO task (id, title, description, due_date, scheduled_time, priority, list_id, tags, recurrence_rule,
               recurrence_anchor, difficulty, estimated_minutes, skill_id, attribute_id, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            [uid(), task.title, task.description, next, task.scheduledTime, task.priority, task.listId, JSON.stringify(task.tags),
             JSON.stringify(task.recurrence), task.recurrenceAnchor ?? task.dueDate, task.difficulty, task.estimatedMinutes,
             task.skillId, task.attributeId, now],
          );
        }
      }
    }

    // Achievements
    const done = await db.getFirstAsync<{ c: number }>("SELECT COUNT(*) AS c FROM task WHERE status = 'done'");
    const ch2 = await db.getFirstAsync<{ total_xp: number }>("SELECT total_xp FROM character WHERE id = 'hero'");
    const unlockedRows = await db.getAllAsync<{ achievement_id: string }>('SELECT achievement_id FROM achievement_unlock');
    const total = ch2?.total_xp ?? 0;
    const newly = evaluateAchievements(
      { tasksCompleted: done?.c ?? 0, level: levelFromTotalXp(total).level, totalXp: total, bestHabitStreak: 0, habitCheckins: 0 },
      new Set(unlockedRows.map((r) => r.achievement_id)),
    );
    for (const a of newly) await db.runAsync('INSERT OR IGNORE INTO achievement_unlock (achievement_id, unlocked_at) VALUES (?, ?)', [a, now]);
    result.unlocked = newly;
  });

  return result;
}

/** Reopening is allowed; it never removes already-granted rewards and re-completing never re-grants them. */
export async function reopenTask(id: string) {
  const db = await getDb();
  await db.runAsync("UPDATE task SET status = 'open', completed_at = NULL WHERE id = ?", [id]);
}

export async function getHeroSummary() {
  const db = await getDb();
  const ch = await db.getFirstAsync<{ name: string; total_xp: number; appearance_stage: number }>("SELECT * FROM character WHERE id = 'hero'");
  const w = await db.getFirstAsync<{ equipment_coins: number; real_coins: number }>('SELECT * FROM reward_wallet WHERE id = 1');
  const lvl = levelFromTotalXp(ch?.total_xp ?? 0);
  return {
    name: ch?.name ?? '',
    totalXp: ch?.total_xp ?? 0,
    stage: ch?.appearance_stage ?? 0,
    level: lvl.level,
    progress: lvl.progress,
    currentXp: lvl.currentXp,
    xpForNext: lvl.xpForNext,
    equipmentCoins: w?.equipment_coins ?? 0,
    realCoins: w?.real_coins ?? 0,
  };
}
