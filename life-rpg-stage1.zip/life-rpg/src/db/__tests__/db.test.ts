import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getDb } from '../client';
import { completeTask, createTask, getHeroSummary, getTasksForDate, reopenTask } from '../taskService';

// Runs the REAL schema + services against node:sqlite via test-support/expo-sqlite-shim.mjs.

test('first run creates all tables, seed data and schema version', async () => {
  const db = await getDb();
  const tables = (await db.getAllAsync<{ name: string }>("SELECT name FROM sqlite_master WHERE type='table'")).map((r) => r.name);
  for (const t of ['user', 'task_list', 'task', 'habit', 'habit_log', 'reminder', 'character', 'skill', 'attribute', 'reward_wallet', 'reward_transaction', 'achievement_unlock', 'custom_reward']) {
    assert.ok(tables.includes(t), `missing table ${t}`);
  }
  assert.equal((await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version'))?.user_version, 1);
  assert.equal((await db.getFirstAsync<{ c: number }>('SELECT COUNT(*) c FROM skill'))?.c, 5);
  assert.equal((await db.getFirstAsync<{ c: number }>('SELECT COUNT(*) c FROM attribute'))?.c, 5);
  assert.equal((await db.getFirstAsync<{ c: number }>('SELECT COUNT(*) c FROM reward_wallet'))?.c, 1);
  // opening again must not re-seed
  await getDb();
  assert.equal((await db.getFirstAsync<{ c: number }>('SELECT COUNT(*) c FROM user'))?.c, 1);
});

test('task persists and shows up for its date', async () => {
  const id = await createTask({ title: 'ذاكر JavaScript', dueDate: '2026-11-14', priority: 2, difficulty: 3, skillId: 'programming', attributeId: 'intelligence' });
  const list = await getTasksForDate('2026-11-14');
  assert.equal(list.find((t) => t.id === id)?.title, 'ذاكر JavaScript');
});

test('completing pays once: tap twice, reopen and complete again', async () => {
  const id = await createTask({ title: 'مهمة مكافأة', dueDate: '2026-11-14', priority: 3, difficulty: 5, skillId: 'fitness' });
  const before = await getHeroSummary();
  const r1 = await completeTask(id);
  assert.equal(r1.rewarded, true);
  const r2 = await completeTask(id); // double tap
  assert.equal(r2.rewarded, false);
  await reopenTask(id);
  const r3 = await completeTask(id); // reopen + complete again
  assert.equal(r3.rewarded, false);

  const after = await getHeroSummary();
  assert.equal(after.totalXp - before.totalXp, r1.xp);
  assert.ok(after.equipmentCoins > before.equipmentCoins && after.realCoins > before.realCoins);

  const db = await getDb();
  const skill = await db.getFirstAsync<{ xp: number }>("SELECT xp FROM skill WHERE id='fitness'");
  assert.equal(skill?.xp, r1.xp); // skill advanced exactly once
  const rows = await db.getAllAsync("SELECT 1 FROM reward_transaction WHERE related_entity_id = ?", [id]);
  assert.equal(rows.length, 3); // xp + equipment + real, once
});

test('recurring task spawns exactly one next occurrence', async () => {
  const id = await createTask({ title: 'قراءة', dueDate: '2026-11-14', recurrence: { freq: 'daily', interval: 1 } });
  await completeTask(id);
  await reopenTask(id);
  await completeTask(id); // must not create a second copy for the 15th
  const db = await getDb();
  const next = await db.getAllAsync("SELECT * FROM task WHERE title = 'قراءة' AND due_date = '2026-11-15'");
  assert.equal(next.length, 1);
});

test('a wallet balance never goes negative from task flow and levels/achievements update', async () => {
  const h = await getHeroSummary();
  assert.ok(h.equipmentCoins >= 0 && h.realCoins >= 0);
  const db = await getDb();
  const unlocked = (await db.getAllAsync<{ achievement_id: string }>('SELECT achievement_id FROM achievement_unlock')).map((r) => r.achievement_id);
  assert.ok(unlocked.includes('tasks_1'));
});
